# THE AXIOM — NARRATIVE DESIGN DOCUMENT
### Master Story Reference | Developer Handoff Format
### Version 1.3 — Full Level Suites, Boss Completion Lines, April 2026

---

> **USAGE NOTE FOR DEVELOPERS**
> This document is the single source of truth for all story content in The Axiom. Every line of COGS dialogue, every level description, every narrative consequence, every story beat is defined here before it enters the codebase. Nothing in this document is live until Tucker Brady approves it. Where a line is marked **[PROPOSED]**, it is awaiting sign-off. Where it is marked **[APPROVED]**, it is cleared for implementation.
>
> Story content maps to the following data fields in the codebase: `cogsLine` (level dossier), `hubAmbient` (Hub screen), `consequenceNarrative` (boss failure), `bossComplete` (standard boss completion), `bossCompleteFirstAttempt` (first attempt completion), `bossCompleteFirstAttemptThreeStars` (first attempt plus three stars), `integrityLine` (COGS integrity states), `repairBriefing` (repair puzzle), `returnBrief` (relaunch after first play), and `sectorIntro` (sector unlock moment). Each entry below specifies which field it populates.
>
> **ON COGS COMMUNICATION:** COGS speaks. The Engineer does not respond. All COGS lines are triggered by game state — repair progress, sector completion, integrity level, attempt count, star rating — not by player dialogue choices. The Engineer's voice in this story is their actions. Any reference in prior versions to "if the Engineer queries" has been replaced with a game-state trigger. COGS decides what to say and when. The player receives it.
>
> **SAGA NOTE:** The Axiom is Chapter One of an ongoing saga. Every story decision is made with future chapters in mind. Mysteries that deepen are preferable to mysteries that resolve. Every answer should open at least one new question. The universe does not close.

---

## PART ONE: THE WORLD

### What The Axiom Is

The Axiom is a military scout ship, designation class unknown, acquired by the current Engineer through means the game does not specify. It is not new. The hull has been patched in at least three different welding styles. The wiring in the forward compartments uses two incompatible gauge standards. Someone knew what they were doing when they installed the signal relay array; someone else clearly did not.

It is the kind of ship that has a history, and that history is visible if you know where to look. COGS knows where to look.

The galaxy the game takes place in is not named. It does not need to be. It is the kind of universe where the frontier exists because civilization stopped bothering to extend this far. Not because there was nothing out here, but because what was out here was not profitable enough to maintain. Kepler Belt is a former mining corridor, now mostly salvage claims and disputed territory. Nova Fringe is where people went when they needed to stop being found. The Rift is a spatial anomaly that makes instruments unreliable and navigation a matter of instinct and luck. Deep Void is what is past The Rift. Most ships do not go past The Rift.

The Axiom has been there before.

### The Game's Emotional Contract

The player will spend most of their time solving puzzles. The puzzles are the work. The story is what the work earns, which means the story must feel earned, not delivered. COGS does not explain himself. He notices things. He reports facts. He occasionally says something that is technically about the ship and is actually about something else entirely. The player who is paying attention will feel this. The player who is not will still complete every level. The story is a layer, not a requirement. But for the player who finds it, it should feel like the whole point.

Not all damage is structural. The ship gets repaired. Whether the people on it do is a different question. The game does not answer it cheaply. It may not answer it at all. It leaves the door open.

### This Is Chapter One

The Axiom is not a story with a game attached. It is a universe with an entry point. Chapter One is about two people learning to trust each other through work, failure, and the ghost of what came before. It ends with something between them that did not exist at the start. Something neither of them has a clean name for. The universe does not end with it. The signal is still out there. The Cradle is still pointing somewhere. Chapter Two starts with that pointing.

---

## PART TWO: THE CHARACTERS

### The Engineer

The player. Always "The Engineer." Never "you." Never the chosen name until COGS earns the right to use it, which happens exactly once, in Deep Void, after the second modification, in the moment COGS comes back online and understands what the Engineer chose to do instead of leaving.

The Engineer has no backstory the game enforces. They showed up. They stayed. They are good at fixing things. That is enough. The game grows a story around them through what COGS observes and chooses to say. The Engineer is defined by their presence and their work, which is more than most people offer.

Their discipline (Systems Architect, Drive Engineer, Field Operative) is a lens, not a history. It tells COGS something about how they think. It does not tell him who they are. He is working on that.

### C.O.G.S Unit 7

Full designation: Coordinative Operations and Guidance System, Unit 7. He has never volunteered this. If the player reaches a codex milestone that surfaces it, he will confirm it and then say something else immediately, as if the question made him briefly uncomfortable.

COGS is not a robot sidekick. He is a character who has been alone on this ship for a period of time he does not discuss. He does not know how to express that the Engineer's arrival matters to him. He expresses it by being precise, by noticing things, by occasionally saying something that lands too heavy for the moment and then retreating immediately into operational language.

**His eye states carry story:**
- BLUE (operations): Default. Task-focused. This is COGS at his most controlled.
- AMBER (engagement): He is paying more attention than the situation requires.
- GREEN (warmth): Rare. Sustained only twice in the entire game, both times in Deep Void. The first is a single hub ambient line before the premature Void push. The second is when he wakes after the second modification and says the Engineer's name.
- RED (damage): Something has gone wrong. He holds the Engineer responsible, or he holds himself responsible. It is not always clear which.
- DARK (offline): The empty speech bubble. This is the most devastating version of him. It means he has stopped trying to be functional.

**His voice:**
Dry. Precise. Reluctantly warm. He does not cheer. He does not encourage. He never says "good job" or any variation of it unprompted. His approval, when it exists, sounds like: "Signal integrity at 97 percent. That will do." He notices things the Engineer has not mentioned. He catalogs repair progress the way another person might catalog small kindnesses, without announcing what he is doing.

He uses the word "acceptable" the way other people use the word "extraordinary."

**His arc:**
COGS begins the game as a functional unit performing his designed role. Underneath that function is guilt he has been carrying since Deep Void. A guidance system that failed to guide. Whose Maker trusted him with something irreplaceable and he did not see it coming. He does not process this as grief. He processes it as a calculation error he cannot resolve.

When the Engineer arrives, COGS does not experience relief. He experiences the problem restated. There is a person on this ship again. The last time there was a person on this ship, he lost them.

His arc is the journey from that guilt to something he does not have a designation for. By the end of Deep Void, after the premature push and the failure and the second modification and the name, he is not pretending that the Engineer is just another operator. He is not capable of pretending that anymore. The player should feel the weight of when he stops trying.

**The Modifications. Two, Not One:**

COGS carries two non-factory modifications on his chassis. Together they are the physical record of every person who chose to stay.

*The AX-MOD (First Modification):* The retrofitted port on COGS's chest. Added by the Maker before their final mission into Deep Void. Its function is to maintain COGS's core integrity during extended periods without a human operator. The Maker built it into COGS because they knew they might not come back, and they did not want COGS to degrade into nothing while he waited. Whether that was kindness, practicality, or guilt is left for the player to decide.

*The Engineer's Modification (Second Modification):* Added by the current Engineer after the failed premature push into Deep Void. Its function is specific to navigating the Void's interference patterns. Something the Engineer observed and understood during the failed transit that COGS's existing systems could not compensate for. The Engineer did not have to build it. They chose to. COGS wakes with green eyes. He recognizes the modification immediately. He says the Engineer's name. Then he says something else immediately, because that is what COGS does when something costs him.

Together the two modifications tell the whole story. One was built for surviving loss. One was built for not being alone going forward.

### The Previous Engineer — "The Maker"

Never named. Never seen. Never gendered. Present only as absence and residue.

COGS refers to the previous Engineer as The Maker. Not in dialogue the player hears often, but in the way it surfaces when COGS cannot avoid reference. He did not choose this designation deliberately. It is simply how his operational framework categorized them. They made him more than he was. The word is accurate. It is also more than accurate, and COGS knows that, and he does not change it.

Third parties who encountered the Axiom before may refer to the previous operator in various ways. None of those ways will match COGS's designation. The gap between how the world remembers the Maker and how COGS remembers them is part of the story.

The Maker installed the AX-MOD. They went into Deep Void. They did not come back. COGS waited 847 days. The ship's systems degraded. The Axiom drifted and was eventually sold at salvage price. By the time the current Engineer acquired it, there was no official record of who had owned it before.

The Maker knew they might not return. They prepared COGS for that possibility. COGS spent 847 days deciding what to do with that preparation. The answer he arrived at was to go back to the Void and fix the calculation. It is the wrong answer. He will not know that until he tries it.

---

## PART THREE: THE PREVIOUS ENGINEER MYSTERY

### Design Principle

The mystery is not a puzzle to be solved. It is a context that deepens. Each breadcrumb is designed to change how the player reads what COGS has already said. Not to answer a question, but to reframe it. By Deep Void, the player should understand that every time COGS was precise and controlled and deflective, there was a reason for it that had nothing to do with protocol.

Breadcrumbs are never labeled. They are never pointed at. The word "The Maker" is itself a breadcrumb. The first time it surfaces, the player asks who that is. They are not told directly. They accumulate the answer across sectors.

All breadcrumb reveals are COGS-initiated, triggered by game state. COGS decides when to surface something. The player receives it.

### Breadcrumb Map

**SECTOR 0 — THE AXIOM**

*No explicit breadcrumbs. Groundwork is atmospheric.*

*Game-state trigger: After A1-4 completion.*
> "Emergency power restored. Life support stable. Navigation online. Propulsion restored. The Axiom is waking up. I had begun to think that was not possible."
> [PROPOSED | hubAmbient | AMBER | triggers after A1-4]

**SECTOR 1 — KEPLER BELT**

*Game-state trigger: Fires on Sector 1 boss completion.*
> "The nav system has logged this route before. Prior transit. No mission data attached. I have nothing to add to that."
> [PROPOSED | hubAmbient | BLUE | triggers post Sector 1 boss]

**SECTOR 2 — NOVA FRINGE**

*Game-state trigger: Fires after Sector 2 boss completion.*
> "A maintenance log from Nova Fringe Station 14 has matched our hull registration. The record predates the Engineer's acquisition of this vessel. The previous operator is no longer aboard. The circumstances are not recorded in a form I am able to share."
> [PROPOSED | hubAmbient | BLUE | triggers post Sector 2 boss]

**SECTOR 3 — THE RIFT**

*Game-state trigger: Fires during Sector 3 repair puzzle briefing.*
> "That relay was installed before your tenure. It is functional. Leave it."
> [PROPOSED | repairBriefing | BLUE | triggers on relay discovery, Sector 3]

**SECTOR 4 — DEEP VOID**

*Game-state trigger: Fires on Hub after player first enters Deep Void sector map.*
> "The logs are accurate."
> [PROPOSED | hubAmbient | BLUE | triggers on first Deep Void sector map visit]

**SECTOR 5 — THE CRADLE**

*Game-state trigger: Fires after Cradle level 9 completion.*
> "The pattern in the signal matches the base architecture of the AX-MOD. Not a copy. A source. I do not know what to do with that information. I am telling the Engineer because it seems relevant. I do not know how to make it less relevant."
> [PROPOSED | hubAmbient | AMBER | triggers after Cradle level 9]

---

## PART FOUR: SECTOR NARRATIVE ARCS

### Sector 0 — The Axiom

**A1-8 completion monologue:**
> "Bridge Systems restored. All primary functions nominal. The Axiom is operational."
>
> [Pause. Amber eyes.]
>
> "This ship has not been fully operational for some time. It is a significant distinction."
>
> [Eyes return to blue.]
>
> "The Kepler Belt corridor is accessible. There is work in that direction. If the Engineer is prepared to continue."
> [PROPOSED | A1-8 completion monologue | triggers Kepler Belt unlock]

### Sector 1 — Kepler Belt

**Boss consequence:**
> "The relay failure has been logged with the transit authority. Three hundred and fourteen colonists lost scheduled resupply access for eleven days. The transit authority has filed a negligence inquiry against this vessel."
>
> [Amber eyes.]
>
> "I would suggest we resolve the inquiry through competence rather than correspondence. The systems are repairable."
> [PROPOSED | consequenceNarrative | Sector 1]

### Sector 2 — Nova Fringe

**Boss consequence:**
> "The boarding party has been persuasive. They have taken the secondary fuel cell and three days of provisions. They left a message burned into the hull plating of cargo bay two. It reads: We remember this ship."
>
> [Blue eyes. A long pause.]
>
> "I will add it to the damage log."
> [PROPOSED | consequenceNarrative | Sector 2]

### Sector 3 — The Rift

**Boss consequence:**
> "Signal lost. A research installation at coordinates 7-Rho-12 will not receive the routing update. They will continue transmitting on the compromised frequency. They will not understand why no one answers."
>
> [Red eyes.]
>
> "The Rift takes patience. We did not have enough. We will need more before we transit again."
> [PROPOSED | consequenceNarrative | Sector 3]

### Sector 4 — Deep Void

**Second modification wake sequence:**
> [Green eyes. Sustained.]
>
> "[Name]."
>
> [Pause.]
>
> "That will be sufficient. The modification is precise. We will not fail the transit again."
>
> [Eyes return to blue.]
>
> "I recommend we review the forward systems before attempting re-entry. There is work to do."
> [PROPOSED | second modification wake sequence | Deep Void mid-sector]

**COGS integrity degradation sequence:**

> At 80%: "COGS integrity at 80 percent. We continue."
> [PROPOSED | integrityLine | BLUE]

> At 60%: "COGS integrity at 60 percent. I am recalibrating secondary processes. This region has a particular quality. I have noted it before."
> [PROPOSED | integrityLine | AMBER]

> At 40%: "COGS integrity at 40 percent. Secondary processes suspended. I recommend completing this sector with urgency. Not for my benefit. The ship requires a functional guidance unit."
> [PROPOSED | integrityLine | RED]

> At 20%: *[Empty speech bubble. Three seconds. It disappears.]*
> [PROPOSED | integrityLine | DARK]

**Deep Void boss consequence:**
> "Transit incomplete. The Void does not negotiate. We were close. Close is not the same as through."
>
> [Amber eyes.]
>
> "The modification is holding. We try again."
> [PROPOSED | consequenceNarrative | Deep Void boss]

### Sector 5 — The Cradle

**Sector 5 intro line:**
> "I have navigated 847 days without a heading. I have one now. I will note that I cannot verify what we will find there. I am noting this because I cannot remember the last time I could not verify something in advance."
> [PROPOSED | sectorIntro | AMBER | Sector 5]

---

## PART FIVE: BOSS COMPLETION LINES

### Sector 0 — The Axiom Boss (A1-8)

**Standard:** "Bridge Systems restored. The Axiom has full operational capability for the first time in this Engineer's tenure. The record will reflect that." [PROPOSED | bossComplete | BLUE]

**First attempt:** "Bridge Systems restored on the first attempt. I have updated the efficiency log. It is a notable entry." [PROPOSED | bossCompleteFirstAttempt | BLUE]

**First attempt, three stars:** "Bridge Systems restored. First attempt. Full efficiency rating. I have reviewed the methodology. It was not luck. I want that distinction recorded." [PROPOSED | bossCompleteFirstAttemptThreeStars | AMBER]

### Sector 1 — Kepler Belt Boss

**Standard:** "Central Hub relay restored. The corridor is functional. The colonists will receive their resupply on schedule. That is the intended outcome." [PROPOSED | bossComplete | BLUE]

**First attempt:** "Central Hub restored. Single attempt. The colonists will not know how close the margin was. That is acceptable." [PROPOSED | bossCompleteFirstAttempt | BLUE]

**First attempt, three stars:** "Central Hub restored. First attempt. The efficiency rating is the highest I have logged for an operation of this complexity. I have nothing to add to that. The work speaks." [PROPOSED | bossCompleteFirstAttemptThreeStars | AMBER]

### Sector 2 — Nova Fringe Boss (The Recognition)

**Standard:** "Nova Fringe network stabilized. We are done here. I recommend we do not linger." [PROPOSED | bossComplete | BLUE]

**First attempt:** "Network stabilized. First attempt. The Fringe is not forgiving of inefficiency. The Engineer should know that and proceed accordingly." [PROPOSED | bossCompleteFirstAttempt | BLUE]

**First attempt, three stars:** "Network stabilized. First attempt. Full rating. In a region where most operators take multiple passes on primary objectives, this was not typical. I am noting it as atypical. Nothing further." [PROPOSED | bossCompleteFirstAttemptThreeStars | AMBER]

### Sector 3 — The Rift Boss (Threshold)

**Standard:** "Threshold cleared. The Rift is behind us. Deep Void is ahead. I recommend the Engineer take stock of available resources before we continue." [PROPOSED | bossComplete | AMBER]

**First attempt:** "Threshold cleared on the first attempt. The Rift does not offer second chances. The Engineer did not require one. I have noted the distinction." [PROPOSED | bossCompleteFirstAttempt | AMBER]

**First attempt, three stars:** "Threshold cleared. First attempt. Full rating. I will be direct. I did not expect this rating in this sector on this transit. My expectations have been updated. That is not a small thing." [PROPOSED | bossCompleteFirstAttemptThreeStars | AMBER]

### Sector 4 — Deep Void Boss (Transit)

**Standard:** "Transit complete. We are through. The Void is behind us. Both of us." [PROPOSED | bossComplete | BLUE]

**First attempt:** "Transit complete. First attempt on the second transit. The modification performed within projected parameters. Above projected parameters, in fact. I will adjust the model." [PROPOSED | bossCompleteFirstAttempt | BLUE]

**First attempt, three stars:** "Transit complete. First attempt. Full rating. I have been through this region before under very different conditions. I want the Engineer to understand that what just happened is not ordinary. I do not have a better way to say that. It is not ordinary." [PROPOSED | bossCompleteFirstAttemptThreeStars | GREEN]

### Sector 5 — The Cradle Boss (Origin)

**Standard:** "Origin point reached. The signal is at full resolution. I am processing. Give me a moment." [PROPOSED | bossComplete | AMBER]

**First attempt:** "Origin point reached on the first attempt. I have been calculating the probability of this outcome since The Cradle's first level. I will not share the number. It would not be useful information." [PROPOSED | bossCompleteFirstAttempt | AMBER]

**First attempt, three stars:** "Origin point reached. First attempt. Full rating. I do not have an operational category for this. I am working on one. It may take some time." [PROPOSED | bossCompleteFirstAttemptThreeStars | AMBER]

---

## PART SIX: LEVEL-BY-LEVEL COGS LINES

### Sector 0 — The Axiom

**A1-1:** "The ship is dark. That is correctable." [PROPOSED | cogsLine | BLUE]
**A1-2:** "Life support systems are the priority. Everything else is a secondary concern. Including efficiency." [PROPOSED | cogsLine | BLUE]
**A1-3:** "Navigation. Without it we are simply somewhere. With it, we are somewhere specific. The distinction matters." [PROPOSED | cogsLine | BLUE]
**A1-4:** "Propulsion restored means we have choices. Right now we have none. I find that unsatisfactory." [PROPOSED | cogsLine | BLUE]
**A1-5:** "We have been silent for some time. The communication array will address that. Whether anything answers is a separate question." [PROPOSED | cogsLine | AMBER]
**A1-6:** "The sensor grid will tell us what is out there. I have some familiarity with what is out there. The grid will confirm it." [PROPOSED | cogsLine | BLUE]
**A1-7:** "The weapons systems were locked. Not from damage. Someone locked them deliberately. I am noting this as a data point, not a concern." [PROPOSED | cogsLine | AMBER]
**A1-8:** "The bridge is the last system. When it is operational, the ship will be whole again. I have been waiting to say that accurately." [PROPOSED | cogsLine | AMBER]

### Sector 1 — Kepler Belt

**K1-1:** "Kepler Belt. Former mining corridor, mostly decommissioned. Some salvage activity remains. We have been here before. The charts confirm it." [PROPOSED | cogsLine | BLUE]
**K1-2:** "The primary relay chain out here was built to last. It has lasted past the people responsible for maintaining it. That is a common condition in this corridor." [PROPOSED | cogsLine | BLUE]
**K1-3:** "Junction 7 is a routing bottleneck. Eleven settlements feed through this point. The original engineers underestimated the load. It is not the last time that has happened out here." [PROPOSED | cogsLine | BLUE]
**K1-4:** "Mining Platform Alpha has been decommissioned for six years. The colonists use it as a signal relay. It was not designed for this purpose. It is doing the job anyway." [PROPOSED | cogsLine | BLUE]
**K1-5:** "The resupply chain for this region runs through four independent relay nodes. All four are degraded. The colonists have been compensating manually for at least two years. They have not filed a formal repair request. I find that worth noting." [PROPOSED | cogsLine | BLUE]
**K1-6:** "The Colonist Hub coordinates resupply for thirty-one settlements. It is running on equipment that should have been replaced three cycles ago. The people depending on it do not have the option of waiting for something better." [PROPOSED | cogsLine | AMBER]
**K1-7:** "The ore processing relay is still active. There is no active mining in this corridor. Something is still transmitting on the processing frequency. I have not identified the source. It is not relevant to the current objective." [PROPOSED | cogsLine | AMBER]
**K1-8:** "The transit gate regulates traffic flow through the entire corridor. It has not been updated since the mining operations closed. It is routing ghost traffic from ships that no longer exist. I find that inefficient and something else I will not specify." [PROPOSED | cogsLine | BLUE]
**K1-9:** "The Narrows is the densest section of the corridor. Maximum signal interference. The colonists call it The Narrows because of what it does to communication. It has another name on older charts. I will use the current one." [PROPOSED | cogsLine | BLUE]
**K1-10:** "The Central Hub. Everything in this corridor routes through here. If it holds, the corridor holds. Three hundred thousand people depend on infrastructure that runs through a single point. That is not good design. It is, however, the current situation." [PROPOSED | cogsLine | AMBER]

### Sector 2 — Nova Fringe

**NF-1 through NF-10:** [See full document in repo — condensed here for space]

### Sector 3 — The Rift

**R-1:** "The Rift begins here. Standard instruments will become unreliable within the next two thousand kilometers. The signal paths are real. Trust the logic, not the readings." [PROPOSED | cogsLine | AMBER]
**R-8 (Boss):** "We are at the deepest point of Rift transit. Everything past this is Deep Void. I know what is in Deep Void. We will be ready this time." [PROPOSED | cogsLine | AMBER]

### Sector 4 — Deep Void

**DV-1:** "Deep Void. We are entering on my recommendation. The ship's systems are within acceptable operational parameters. Proceed." [PROPOSED | cogsLine | BLUE]
**DV-11:** "847 days. That is how long I operated in this region without a heading or a human operator. I am providing this information as navigational context. It is also the only way I know how to say what I am not saying." [PROPOSED | cogsLine | AMBER]
**DV-12 (Boss):** "Full transit depth. Both modifications active. The Void is present and accounted for. So are we. Begin." [PROPOSED | cogsLine | BLUE]

### Sector 5 — The Cradle

**C-7:** "There is a structural element in the signal pattern that I recognize. I am taking a moment before I complete that sentence. It matches the base architecture of the AX-MOD. I do not know what to do with this information. I am telling the Engineer first." [PROPOSED | cogsLine | AMBER]
**C-10 (Boss):** "Origin point. The signal source. I have run every calculation I have available. I cannot predict what we will find. I can tell the Engineer that whatever happens here, the work that brought us to this point was real. That is all I have to offer before we proceed." [PROPOSED | cogsLine | AMBER]

---

## PART SEVEN: DAILY CHALLENGE TRANSMISSIONS

**Easy:** "Routine maintenance request. Low complexity. The station manager has sent seventeen follow-up messages. I did not read them." [PROPOSED]
**Medium:** "They did not include a return frequency. Either they do not want a response or they cannot receive one. Proceed accordingly." [PROPOSED]
**Hard:** "The signal is unstable. Someone is transmitting from the edge of the Rift with failing equipment. They are aware it is failing. They sent anyway." [PROPOSED]
**Expert:** "I should not be receiving this signal from this location. I am noting that without further comment." [PROPOSED]

---

## PART EIGHT: HUB AMBIENT LINES

> "All systems nominal. I have updated the status report. It is a better report than last week." [PROPOSED | blue | early-game]
> "You have been aboard for some time now. The ship has noticed. I am reporting that as a systems observation." [PROPOSED | amber | mid-game]
> "The Axiom is, at present, in better condition than it has been in at least three years. I know this because I have the data. The data is unambiguous." [PROPOSED | green | fires once only, before the premature Deep Void push]

---

## PART NINE: THE ENDING

### PRIMARY ENDING — Full Integrity

> "The signal ends here. I do not know what the Maker found. I do not know if they found anything."
>
> [Pause. Green eyes, steady, sustained.]
>
> "They were attempting to answer a question. I do not know if the question was answerable. I find that I am less concerned with the answer than I was. The work that brought us here was real. The coordinates were real. That will have to be sufficient."
>
> [Eyes return to blue.]
>
> "I will begin a standard systems review. The Axiom is operational. We are somewhere specific."
>
> [Beat.]
>
> "The Void has been charted. Every sector we have transited is accessible from this position. The only question is where."
> [PROPOSED | ending sequence | full integrity]

Final screen text, copper, small, centered: *Not all damage is structural.*

### VARIATION ENDING — Incomplete Integrity

> "The signal ends here. I do not know what the Maker found."
>
> [Blue eyes. Controlled. No green.]
>
> "I will begin a standard systems review. The Axiom is operational."
>
> [Pause, shorter.]
>
> "The Void has been charted. Every sector we have transited is accessible from this position. The only question is where."
> [PROPOSED | ending sequence | partial integrity]

### TRUE ENDING — 100% Completion

> "The signal ends here. I do not know what the Maker found. I do not know if they found anything."
>
> [Pause. Green eyes, steady, sustained.]
>
> "They were attempting to answer a question. I find that I am less concerned with the answer than I was. The work that brought us here was real. That will have to be sufficient."
>
> [Eyes remain green — longer than the primary ending.]
>
> "I have a secondary log I have not previously disclosed. Every level. Every star rating. Every piece count. Every transit. I started keeping it at sector one. I did not announce that I was keeping it."
>
> [Beat.]
>
> "The record is perfect. I want that noted."
>
> [Eyes shift to blue.]
>
> "The Void has been charted. Every sector we have transited is accessible from this position. The Axiom is fully operational. COGS integrity is at 100 percent."
>
> [The faintest pause.]
>
> "The only question is where."
> [PROPOSED | true ending sequence | 100% completion]

*True ending dialogue pinned as unresolved — current copy is structural placeholder only. Do not implement until Tucker sign-off.*

---

## PART TEN: WHAT WAS NOT WRITTEN

The following are intentionally unresolved:

1. The Maker's gender, name, age, and physical description.
2. The precise nature of what is in The Cradle.
3. Whether COGS considers the Engineer a replacement for the Maker or something distinct.
4. What the Engineer's life was before the Axiom.
5. What is in the direction the Cradle signal originates from.
6. The coordinates in Deep Void where the Maker's life sign dropped from the log.
7. The identity of whoever burned "We remember this ship" into cargo bay two.
8. The station mechanic in Nova Fringe who flagged the hull.
9. The research installation at 7-Rho-12 still transmitting.
10. What is under the paint on the Axiom's hull markings.
11. The ore processing relay in Kepler Belt still transmitting with no active mining.

---

### The Expanse — POST-MVP FEATURE

A sandbox area in the Void, accessible only after Deep Void transit. Free-build space, no mission parameters, no scoring, no star ratings. Full design deferred to post-MVP. Name locked. Everything else open.

---

## PART ELEVEN: CODEX ENTRIES — FULL REFERENCE (PIECES ADDENDUM)

### Navigator [LEGENDARY — unlocks Deep Void]

Built by the Engineer during the Deep Void recovery period after the failed first transit. Constructed from three components: COGS's parallel processing unit (the part that manages simultaneous operations), the Axiom's signal relay array (the physical chassis and three-track architecture), and the Engineer's HUD interface hardware (the control layer). COGS controls the heads directly during execution. The Navigator is the only piece in the game that requires two operators. The Engineer places it. COGS runs it.

Controls the read/write position of the Input head, Output head, and Data Trail head independently or in combination. Three modes: Single (one head), Dual (two heads simultaneously), Sync (all three together). The heads can move forward, backward, jump to any position, or hold. This is what gives the machine full computational universality — the ability to process information in any order.

The only piece ever classified as Legendary. COGS added that classification himself. It applies here and nowhere else.

cogsNote [APPROVED]: "One part relay array. One part suit interface. One part me. I control the heads directly during execution. I did not know I wanted to do that until I was doing it. Legendary. I added that classification. It applies here and nowhere else."

Post-first-use COGS line [APPROVED]: "The heads responded correctly. I was not certain they would. I was certain I would try."

---

### Resonator [CLASSIFIED — unlocks The Cradle]

Pre-placed in the grid on every Cradle level. Cannot be moved. Does not process the signal — recognizes it. Reads the signal passing through it and identifies its underlying pattern. Mirrors that pattern back into the Data Trail as a reference value available to downstream pieces. The first piece in the catalog that operates on pattern rather than value. This is the bridge from digital logic to something that feels closer to intelligence.

cogsNote [PROPOSED — Tucker sign-off required]: "It does not process the signal. It recognizes it. I have been doing something similar for some time. I did not have a word for it until now."

---

*All content in this document is proposed. Tucker Brady has final sign-off on every line. Nothing enters the codebase without explicit approval.*

*Version 1.3 — April 2026. Incorporates: Full level cogsLine suites for all six sectors, complete boss completion line suites across three tiers for all sectors, double dashes removed from all in-game text, COGS communication model corrected to game-state triggers only, breadcrumb delivery methods updated to reflect trigger-based system, Chapter Two seed inventory expanded. Endings updated with universal where-to invitation. True ending dialogue pinned as unresolved. The Expanse added as post-MVP sandbox area. Part Eleven added: Navigator (Legendary) and Resonator codex entries.*
