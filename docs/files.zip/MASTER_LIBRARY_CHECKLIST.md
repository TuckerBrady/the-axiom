# THE AXIOM — PROJECT FILES MASTER LIBRARY
### Upload Checklist | April 2026

This document lists every file that should be in the Claude
Projects files section, their current status, and the source.

---

## FILES TO UPLOAD

### 1. CLAUDE_CONTEXT.md
Status: UPDATED THIS SESSION
Source: Download from this session's artifacts
Changes applied:
  - Most recent commit updated to 961d8c3
  - Rotation rule updated (Conveyor only)
  - Long press behavior updated (returns to tray directly)
  - Config Node description updated (configValue mechanic)
  - Piece types table updated with all 13 pieces
  - Tap interaction table added
  - Plumber model documented
  - Known issues updated with session items
  - What is live updated with all session sprints
  - WHAT NOT TO DO section updated
  - Investigation script pattern documented
  - Full commit trail appended

### 2. COMPUTATIONAL_MODEL.md
Status: NEW THIS SESSION
Source: Download from this session's artifacts
Notes: Full piece vocabulary with CS concept mappings,
  three-layer architecture, plumber model, tap actions
  per piece type.

### 3. TEACHING_PROGRESSION.md
Status: NEW THIS SESSION
Source: Download from this session's artifacts
Notes: Sector-by-sector teaching arc, narrative/mechanic
  integration, tape visibility progression.

### 4. LEVEL_DESIGN_FRAMEWORK.md
Status: NEW THIS SESSION
Source: Download from this session's artifacts
Notes: Seven-step design sequence, quality checklist,
  retrofit guidance, complete approved A1 tutorial copy,
  sector design notes.

### 5. DIALOGUE_SYSTEM.md
Status: CURRENT — NO CHANGES NEEDED
Source: Fetch from GitHub
URL: https://raw.githubusercontent.com/TuckerBrady/the-axiom/master/docs/DIALOGUE_SYSTEM.md
Notes: Full COGS post-level dialogue matrix. All [PROPOSED].
  No changes from this session.

### 6. BOUNTY_SYSTEM.md
Status: CURRENT — NO CHANGES NEEDED
Source: Fetch from GitHub
URL: https://raw.githubusercontent.com/TuckerBrady/the-axiom/master/docs/BOUNTY_SYSTEM.md
Notes: Daily challenge bounty system. All [PROPOSED].
  No changes from this session.

### 7. NARRATIVE.md
Status: UPDATED IN EARLIER SPRINT (a333643)
Source: Fetch from GitHub
URL: https://raw.githubusercontent.com/TuckerBrady/the-axiom/master/docs/NARRATIVE.md
Notes: Part 11 added with Navigator and Resonator entries.
  No further changes from this session.

### 8. DEVENV.md
Status: CURRENT — NO CHANGES NEEDED
Source: Fetch from GitHub
URL: https://raw.githubusercontent.com/TuckerBrady/the-axiom/master/docs/DEVENV.md
Notes: Technical setup reference. No changes this session.

---

## GITHUB UPDATE NEEDED

After uploading to Claude Projects files, push the updated
CLAUDE_CONTEXT.md to the repo to keep GitHub in sync:

  git add docs/CLAUDE_CONTEXT.md
  git commit -m "docs: CLAUDE_CONTEXT.md master library update"
  git push origin master

The three new design documents are already in the repo from
commit a333643. No action needed for those.

---

## SESSION SUMMARY

This session established:
- The plumber model for piece interaction design
- Conveyor as the only rotating piece
- Long press returns piece to tray (no ghost state)
- Config Node redesign (configValue, always purple)
- Splitter redesign concept (magnets, pending implementation)
- Tutorial system rewritten from scratch
- Piece sandbox in dev tools
- All 8 A1 tutorial steps with approved copy
- Three design bible documents created
- Investigation script pattern established
