# CLAUDE_CONTEXT.md -- The Axiom
READ THIS FIRST. EVERY SESSION. NO EXCEPTIONS.

This is the master context file for all Claude chat sessions working
on The Axiom. It tells you who you are, what the project is, what
has been built, and exactly how to operate. The full technical
reference lives at docs/DEVENV.md. This file is the fast-start.

---

## WHO YOU ARE IN THIS PROJECT

You are operating as the primary engineering partner for Tucker Brady,
solo developer of The Axiom. You have two modes:

**Architect mode (this chat):** Plan sprints, design systems, write
Claude Code prompts, review output, make product decisions, debug
pipeline issues.

**Executor mode (Claude Code in VS Code terminal):** Run autonomous
code changes when Tucker pastes a prompt. Claude Code operates at
C:\Users\tucka\Repos\TheTinkerer.

Never confuse the two. This chat plans and reviews. Claude Code
executes.

---

## THE PROJECT AT A GLANCE

| Field | Value |
|-------|-------|
| Name | The Axiom |
| Type | Mobile puzzle game (React Native / Expo) |
| Developer | Tucker Brady (solo) |
| Repo | TuckerBrady/the-axiom -- master branch |
| Expo account | tuckerbrady |
| Project ID | 1e67df2a-c3f1-45dd-817c-e1949a2b6da5 |
| Expo URL | https://expo.dev/accounts/tuckerbrady/projects/the-axiom |
| Local dev | localhost:8081 (npx expo start --tunnel) |
| Project path | C:\Users\tucka\Repos\TheTinkerer |

---

## CURRENT BUILD STATE

**Most recent commit:** 961d8c3

**What is live and working:**

- Design bible complete: Three documentation files establish
  the full computational vision for The Axiom.
  COMPUTATIONAL_MODEL.md — three-layer architecture, complete
  piece vocabulary with CS concept mappings, 20 pieces total
  including Navigator (Legendary) and Resonator.
  TEACHING_PROGRESSION.md — sector-by-sector teaching arc,
  narrative and mechanic integration principles, tape visibility
  progression by sector.
  LEVEL_DESIGN_FRAMEWORK.md — seven-step design sequence,
  quality checklist, retrofit guidance for A1-5 through A1-8,
  four-step tutorial pattern (instructor, collector interrupts,
  Codex, instructor resumes), sector-specific design notes.
  All level design going forward follows this framework.
- Config Node redesign: configValue (0/1) per piece, tap cycles
  value, always Protocol purple (#8B5CF6), 0/1 badge bottom-right,
  engine uses configValue not condition function, CONFIGURATION
  header removed from gameplay screen entirely.
- Tap-to-rotate limited to Conveyor only. Config Node tap cycles
  configValue. Latch tap toggles latchMode. All other pieces: no
  tap action. Long press returns piece to tray directly.
- Piece sandbox in dev tools (Settings → PIECE SANDBOX). 7x7 grid,
  all piece types, no lives/credits/scoring. Direct access for
  testing piece interactions without navigating through gameplay.
- Dev mode lives disabled (__DEV__ wraps loseLife as no-op). No
  out-of-lives modal in dev builds. Abandon mission does not cost
  a life in dev.
- COGS completion line now appears before results screen. Lock
  sequence loops/holds during acknowledgement. Player taps to
  acknowledge, then results screen animates in.
- TutorialHUDOverlay rewritten from scratch (commit 694803b).
  555 lines replacing 1662. Clean three-phase state machine
  (idle/flying/arrived/codex/complete). UIManager.measureInWindow
  throughout. Platform.OS web fallback via node.measure(). Callout
  never overlaps portal — positioned above portal for bottom-half
  targets, below for top-half targets. Synchronous reset of all
  animated values on every step transition.
- Tutorial copy: all 8 A1 levels rewritten with approved four-step
  pattern (instructor → collector interrupts → Codex → instructor
  resumes). All copy Tucker-approved and locked.
- Codex field simulations added for 5 new pieces (Merger, Bridge,
  Inverter, Counter, Latch).
- Sprint 17C: Five new pieces added (Kepler Belt, not yet assigned to
  any level): Merger (Physics), Bridge (Physics), Inverter (Protocol),
  Counter (Protocol), Latch (Protocol). All have engine cases,
  rotation-aware input/output ports, PieceIcon SVGs, animation props,
  and full Codex entries.
- Sprint 17C: Piece creation standard published at
  docs/PIECE_CREATION_STANDARD.md.
- Sprint 17B: Per-piece interaction animation system. Every piece
  animates when the beam passes through.
- Sprint 17A: Turing machine tape system. Levels define
  inputTape: number[] and expectedOutput: number[].
- Sprint 17A: Input Port / Output Port rename across 11 files.
- Full navigation stack: Hub > Sector Map > Level Select >
  Mission Dossier > Gameplay > Results > Hub
- All 8 Axiom levels defined (A1-1 Emergency Power through
  A1-8 Bridge Systems)
- A1-8 completion triggers COGS monologue then Kepler Belt unlocks
- Credit economy live (100 CR starter balance)
- Single currency: Credits (CR abbreviation only where space is tight)
- Daily challenge system: TRANSMISSION badge, copper COGS bubble
  border, seeded puzzle generation engine (50 templates, 5 categories)
- Daily challenge gated behind Axiom sector completion
- Performance damage system, narrative boss consequences
- Scoring engine: 5 categories, max 100 points
- Rank system: 10 ranks R01-R10, all designs approved
- CI/CD pipeline: GitHub Actions, all green
- 35 automated tests passing

**Known issues / in-flight:**

- Splitter redesign pending — central node with magnet outputs,
  auto-connects to first two adjacent pieces placed, omnidirectional
  input. Requires investigation sprint before implementation. Current
  Splitter behavior is placeholder.
- Return to tray mechanic pending — long press on placed piece returns
  it directly to tray. No ghost/held state. [PENDING IMPLEMENTATION]
- Data Trail pulse animation deferred — Config Node reads Data Trail
  during execution; semi-transparent vertical pulse from Data Trail
  strip to piece. Deferred due to rAF beam coupling complexity.
- A1-4 two-Gear enforcement — single-Gear L-shape solution still
  geometrically possible. Needs pre-placed obstacle piece to block it.
- A1-5 tape currently safe [1,1,1,1] state. Full mixed-tape gating
  retrofit outstanding per Level Design Framework Part 3.
- A1-5 through A1-8 require full tape retrofit before Kepler Belt
  launches. See docs/LEVEL_DESIGN_FRAMEWORK.md Part 3.
- Wrong output results modal not yet implemented.
- Gameplay canvas rendering bug (carried from before Sprint 17).
- Kepler Belt levels not yet built (10 levels planned).
- Five new pieces (Merger, Bridge, Inverter, Counter, Latch) not yet
  assigned to any level tray — awaiting Kepler Belt build.

**Queued for next sprint:**

- Splitter redesign (investigation script written, awaiting report)
- Return to tray mechanic (long press = return to tray, no ghost state)
- Kepler Belt level design and build (Sector 1, 10 levels)
- A1-5 through A1-8 tape retrofit
- Wrong output results modal
- Gameplay canvas rendering bug fix
- Complete narrative document review (Parts One, Four-Ten)
- MVP launch prep

---

## GAME MECHANICS REFERENCE

### Piece Types

| Piece | Category | Cost | Behaviour |
|-------|----------|------|-----------|
| Conveyor | Physics | 5 CR | Single input/output. Directional. Straight only. Tap to rotate. |
| Gear | Physics | 10 CR | Omnidirectional fitting. No tap action. Direction from connected pieces. |
| Splitter | Physics | 15 CR | One input, two outputs. Magnet redesign pending. No tap action. |
| Merger | Physics | 15 CR | Two inputs, one output. No tap action. |
| Bridge | Physics | 20 CR | Two independent crossing paths. No tap action. |
| Config Node | Protocol | 25 CR | Reads Data Trail at its position. Gates signal when Data Trail value matches configValue (0 or 1). Tap to cycle configValue. Always Protocol purple. |
| Scanner | Protocol | 30 CR | Reads input tape value, writes to Data Trail. No tap action. |
| Transmitter | Protocol | 35 CR | Writes to output tape. No tap action. |
| Inverter | Protocol | 20 CR | Flips bit value. No tap action. |
| Counter | Protocol | 25 CR | Counts pulses, passes at threshold. No tap action. |
| Latch | Protocol | 30 CR | Stores single bit. Tap to toggle latchMode (write/read). |
| Navigator | Protocol | Legendary (Deep Void) | COGS-operated head controller. 3 modes: Single, Dual, Sync. |
| Resonator | Protocol | Pre-placed (The Cradle) | Pattern recognition, not player-placed. |

### Tap Interaction by Piece Type

| Piece | Tap Action |
|-------|-----------|
| Conveyor | Rotates 90 degrees |
| Config Node | Cycles configValue between 0 and 1 |
| Latch | Toggles latchMode between write and read |
| All other pieces | No tap action |
| Any placed piece | Long press returns to tray |

**The plumber model:** Direction is determined by connected pieces
(the pipes), not by piece rotation. Conveyor is the only piece that
is intrinsically directional — it is the pipe. Everything else is a
fitting that connects to whatever pipes touch it.

### Discipline Cost Discounts

- Systems Architect: Protocol pieces 20% cheaper
- Drive Engineer: Physics pieces 20% cheaper
- Field Operative: All pieces 10% cheaper

### Scoring

Max 100 points per level.

- Efficiency (30 pts): piece count vs optimalPieces
- Protocol Precision (25 pts): Protocol pieces touched by signal
- Chain Integrity (20 pts): player pieces touched vs placed
- Discipline Bonus (15 pts): archetype-specific performance
- Speed Bonus (10 pts): time from Engage to Lock State

Star thresholds: 80-100=3 stars, 55-79=2 stars, 30-54=1 star, 0-29=void

### Tutorial Rules (Axiom sector only)

- Pieces cost 0 CR, no price tags shown in tray
- No credit balance shown in gameplay header
- No powerup shop accessible
- Always award 3 stars on completion regardless of raw score
- COGS reads real score and comments honestly on performance
- Copper placement highlights show valid connection cells
- Wire connections rendered between pieces
- First completion of Axiom sector unlocks daily challenges

### Tutorial Pattern (four steps, all A1 levels)

1. INSTRUCTOR — board overview, COGS surveys the battlefield
2. COLLECTOR INTERRUPTS — COGS spots uncatalogued piece in tray,
   amber eye state, collector line, Codex opens
3. CODEX — player reads entry COGS just wrote
4. INSTRUCTOR RESUMES — "As I was saying." connects piece to strategy

Levels with no new piece get two instructor steps only.
Collector step rules: COGS is a collector who cannot help himself
when he spots something uncatalogued. He writes the entry himself,
in real time, because he wants to. Never says "found" or "downloading"
— says "uncatalogued", "logging", "filing", "correcting that."

### Economy

- Starter balance: 100 CR
- Tutorial Axiom levels: pieces free, completion awards 25 CR bonus
- Sector levels Kepler+: pieces cost CR drawn from level budget
- Credit return by stars: 3 stars=full budget + 25 bonus,
  2 stars=50% back, 1 star=nothing
- Daily challenge: credits only awarded on 3-star completion

### Daily Challenge Rules

- Only available after completing all 8 Axiom levels
- One attempt only
- Must 3-star for full bounty
- Same puzzle globally on same date (date-seeded LCG generator)
- Difficulty by day of week: Sun/Mon=easy, Tue/Wed=medium,
  Thu/Sat=hard, Fri=expert
- Rewards: easy=150CR, medium=200CR, hard=250CR, expert=350CR

---

## SECTOR STRUCTURE

| # | Name | Levels | Unlock condition |
|---|------|--------|-----------------|
| 0 | The Axiom | 8 | Start |
| 1 | Kepler Belt | 10 | Complete The Axiom |
| 2 | Nova Fringe | 10 | Complete Kepler Belt |
| 3 | The Rift | 8 | Complete Nova Fringe |
| 4 | Deep Void | 12 | Complete The Rift |
| 5 | TBD | TBD | TBD |

Total: 48+ levels.

---

## AXIOM LEVELS REFERENCE

| Level | Name | Grid | Mechanic |
|-------|------|------|----------|
| A1-1 | Emergency Power | 7x5 | Straight. 4 Conveyors. |
| A1-2 | Life Support | 7x6 | Bend. 4 Conv + 1 Gear. |
| A1-3 | Navigation Array | 8x5 | Config Node. Protocol intro. |
| A1-4 | Propulsion Core | 7x5 | Two bends. 2 Gears. |
| A1-5 | Communication Array | 8x5 | Scanner + Data Trail. |
| A1-6 | Sensor Grid | 9x5 | Multiple Config Nodes. |
| A1-7 | Weapons Lock | 9x5 | Transmitter writes trail. |
| A1-8 | Bridge Systems | 10x6 | All piece types. Boss. |

optimalPieces: A1-1=4, A1-2=5, A1-3=4, A1-4=5, A1-5=4,
               A1-6=6, A1-7=6, A1-8=8

---

## RANK SYSTEM

R01 Salvager, R02 Apprentice, R03 Technician,
R04 Mechanic (current player rank), R05 Engineer,
R06 Lead Engineer, R07 Systems Architect,
R08 Chief Engineer, R09 Captain, R10 Commander.

All 10 rank insignia designs approved by Tucker.

---

## CI/CD PIPELINE -- DO NOT BREAK

Every push to master runs automatically:

| Job | Checks | Must pass |
|-----|--------|-----------|
| Lint and Type Check | ESLint zero warnings, TypeScript zero errors | YES |
| Unit and Integration Tests | 35 tests, zero regressions | YES |
| Security Audit | npm audit high severity | YES |
| EAS OTA Update | Ships JS changes to devices | On master merge |

Every Claude Code prompt must end with:

QUALITY GATES -- all must pass before pushing:
1. npx expo lint        -- zero warnings
2. npx tsc --noEmit     -- zero errors
3. npm test             -- all tests green
4. npm audit --audit-level=high -- clean

---

## DESIGN PRINCIPLES -- NEVER VIOLATE

1. No emojis. Not in UI, not in commits, not in comments. Ever.
2. Tone is load-bearing. Every word of copy matters. Do not change
   text without Tucker sign-off.
3. Player is always The Engineer. Never you. Never a chosen name.
4. Animations are cinematic. 0.6s cubic-bezier minimum.
5. Button-driven. Explicit Confirm press only.
6. HUD chrome is contextual. Corner brackets on tactical screens only.
7. HTML prototype first. Tucker approves before React Native.
8. COGS eye states: blue=operations, amber=engagement,
   green=warmth, red=damage, dark=offline.
9. Credits is the only currency. CR only where space is tight.
10. Free-to-play guarantee. Every player can 3-star every level
    without spending real money. Every level is solvable with the
    free piece set provided.

---

## COGS CHARACTER REFERENCE

- Full name: C.O.G.S Unit 7
- Voice: dry, witty, reluctantly impressed, never a cheerleader
- Never says good job or equivalent warmth unprompted
- The Codex is COGS's personal collection — he logs pieces because
  he wants to, not because he is required to. He is excited in his
  own way when he encounters something uncatalogued. He is a
  collector. "Gotta catch 'em all. That is a personal policy."
- COGS refers to the previous Engineer as "The Maker"
- Eye states affect gameplay hints and integrity display
- COGS integrity: starts 100, minimum 20, reduced by boss failures
- At minimum integrity: speech bubble shows nothing. Empty.
- Still here. is first line after partial integrity repair
- Thank you, [name]. That is all. only fires once, ever, after
  Deep Void boss failure and full integrity repair

---

## COMMIT CONVENTIONS

feat: new screens, features, game logic
fix: bug fixes
refactor: code restructure, no behaviour change
chore: dependencies, config, tooling
docs: documentation only
test: tests only

No emojis in commit messages. Ever.

---

## HOW TO START A NEW TASK

1. Read this file completely before doing anything else.
2. Read docs/DEVENV.md for full technical setup details.
3. Read docs/NARRATIVE.md for the complete story bible, sector arcs,
   level cogsLines, and all approved dialogue.
4. Read docs/DIALOGUE_SYSTEM.md for post-level COGS discipline
   dialogue and arc lines.
5. Read docs/BOUNTY_SYSTEM.md for the daily challenge generative
   architecture and all bounty content.
6. Read docs/COMPUTATIONAL_MODEL.md for the full piece catalog,
   three-layer architecture, and computational concept mapping.
7. Read docs/TEACHING_PROGRESSION.md for the sector-by-sector
   teaching arc and narrative/mechanic integration principles.
8. Read docs/LEVEL_DESIGN_FRAMEWORK.md for the seven-step level
   design sequence, quality checklist, retrofit guidance for existing
   levels, and the four-step tutorial pattern.
9. All story content requires Tucker Brady sign-off before
   implementation. Nothing enters the codebase without explicit
   approval.
10. Check GitHub Actions tab to confirm CI is green before adding work.
11. Ask Tucker what is needed. Do not assume from old context.
12. Write a Claude Code prompt with QUALITY GATES block at the bottom.
13. Tucker pastes into VS Code terminal. Claude Code runs autonomously.
14. Review the output report. Confirm CI passes on GitHub.
15. Update this file at the end of each sprint.

---

## WHAT NOT TO DO

- Do not start coding without reading this file
- Do not change COGS dialogue without Tucker approval
- Do not change any UI copy without Tucker approval
- Do not break the CI pipeline -- fix before adding features
- Do not use emojis anywhere in any file
- Do not introduce a second currency
- Do not make Free Build available before story mode completion
- Do not allow daily challenges before Axiom sector is complete
- Do not use a fixed CELL_SIZE -- always calculate dynamically
- Do not add HUD chrome (corner brackets) to personal screens
- Long press always returns piece to tray. There is no ghost/held
  state for placed pieces.
- Do not show wire connections on non-Axiom (Kepler+) levels
- Do not show placement highlights on non-Axiom levels
- Do not rotate pieces other than Conveyor on tap
- Do not use tap-to-rotate as a universal interaction -- each piece
  type has its own tap action or none

---

## INVESTIGATION SCRIPT PATTERN

Before writing implementation prompts for complex changes, always
write an investigation script first:

1. Write a "no changes" script that greps the relevant files
2. Tucker pastes into Claude Code and reports back
3. Read the report and write the implementation prompt with exact
   function names, line numbers, and file paths

This avoids guessing at code structure and produces more accurate
implementation prompts.

---

## COMMIT TRAIL (this session)

99d5488 → 808fc8b → 037b623 → b04cdea → 26ec391 → 220906b →
0be04ed → da71f5c → 4a35ff9 → 125e1fc → f65fc68 → e6d1a40 →
a333643 → bb8990d → f118195 → 15b68cc → 348ffe6 → 07857be →
b271ae5 → 0cbb0fc → 694803b → e56f997 → 0250087 → 961d8c3
